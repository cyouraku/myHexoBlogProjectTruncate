# Created By Yigang Zhou (Mike)
# https:// MikeTech.it


class Route:

    from_stop = ""
    to_stop = ""
    line_number = 0
    stops = 9999

