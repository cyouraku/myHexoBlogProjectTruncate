# Created By Yigang Zhou (Mike)
# https:// MikeTech.it


def get_line_number(key):
    return int(key[0: 2])