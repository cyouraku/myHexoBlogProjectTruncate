package com.zx.bt;

import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import lombok.extern.slf4j.Slf4j;

//@EnableBatchProcessing
@SpringBootApplication
@Configuration
@EnableAutoConfiguration
//@ComponentScan(basePackages = "com.zx.bt.mybatis.dao")
//@ImportResource({"classpath:mybatis-config.xml","classpath:batch-config.xml","classpath:quartz-config.xml","applicationContext.xml"})
@ImportResource({"classpath:batch-config.xml","classpath:quartz-config.xml"})
//@MapperScan("com.zx.bt.mybatis.dao")
@Slf4j
public class BatchApplication {

	public static void main(String[] args) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		 SpringApplication.run(BatchApplication.class, args);
	}
}
