package com.zx.bt.spider.task;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.zx.bt.spider.SpiderApplicationTests;

/**
 * author:ZhengXing
 * datetime:2018/3/14 0014 13:29
 */
public class FetchMetadataByOtherWebTaskTest extends SpiderApplicationTests {

	@Autowired
	private FetchMetadataByOtherWebTask task;

	@Test
	public void testZhongzisou() {
//		Metadata metadata = task.fetchMetadataByBtrabbit("b01ef8a5ea52c8291a5873e6ce580e05afe7f69c");
		task.put("1619ecc9373c3639f4ee3e261638f29b33a6cbd6");
		task.start();
	}

}