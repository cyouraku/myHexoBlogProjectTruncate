package com.zx.bt.spider.parser;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.zx.bt.common.entity.Metadata;
import com.zx.bt.spider.SpiderApplicationTests;

/**
 * author:ZhengXing
 * datetime:2018-03-18 16:31
 */
public class AbstractInfoHashParserTest extends SpiderApplicationTests{

    @Autowired
    private List<AbstractInfoHashParser> parserList;

    @Test
    public void parse() throws Exception {
        for (AbstractInfoHashParser item : parserList) {
            try {
//                Metadata m = item.parse("89d296c86731a7012d63eae44cf8163512d23d53");
                //1619ecc9373c3639f4ee3e261638f29b33a6cbd6
            	//流浪地球
            	//SLSUDSMCBE5LIOW2HIM7CCAXCHVTRELL
                Metadata m = item.parse("SLSUDSMCBE5LIOW2HIM7CCAXCHVTRELL");
                //print json
                ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                String json = ow.writeValueAsString(m);
                System.out.println(item.metadataType  + "---" + json);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}