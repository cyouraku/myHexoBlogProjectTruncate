package com.wolfbe.chat.util;

/**
 * @author laochunyu
 */
public class Constants {

    public static String DEFAULT_HOST = "localhost";
    public static int DEFAULT_PORT = 9688;
    public static String WEBSOCKET_URL = "ws://localhost:8099/websocket";
}
