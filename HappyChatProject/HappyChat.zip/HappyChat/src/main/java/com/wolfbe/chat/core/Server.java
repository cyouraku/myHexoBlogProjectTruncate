package com.wolfbe.chat.core;

/**
 * @author Andy
 */
public interface Server {

    void start();

    void shutdown();
}
