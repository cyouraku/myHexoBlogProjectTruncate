package com.wolfbe.chat.util;

import org.ligboy.translate.Translate;
import org.ligboy.translate.model.TranslateResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GoogleTranslatorUtil {

	private static final Logger logger = LoggerFactory.getLogger(GoogleTranslatorUtil.class);
	private static final Translate translate = new Translate.Builder()
            .logLevel(Translate.LogLevel.BODY)
            .build();

	/**
	 * Translate any language into Japanese
	 * @param input
	 * @return
	 */
	public static String trans2Jp(String input) {
		String jpTxt = "";
	    try {
	        translate.refreshTokenKey();
	        TranslateResult result = translate.translate(input,
	                Translate.SOURCE_LANG_AUTO, "ja");
	        logger.info(result.toString());
	        //sentences:
	        //targetText:
	        //SourceText:
	        //translit:
	        //sourceLang:
	        jpTxt = result.getTargetText();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return jpTxt;
	}

	/**
	 * Translate any language into English
	 * @param input
	 * @return
	 */
	public static String trans2En(String input) {
		String jpTxt = "";
	    try {
	        translate.refreshTokenKey();
	        TranslateResult result = translate.translate(input,
	                Translate.SOURCE_LANG_AUTO, "en");
	        logger.info(result.toString());
	        jpTxt = result.getTargetText();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return jpTxt;
	}

	/**
	 * Translate any language into Chinese
	 * @param input
	 * @return
	 */
	public static String trans2Cn(String input) {
		String jpTxt = "";
	    try {
	        translate.refreshTokenKey();
	        TranslateResult result = translate.translate(input,
	                Translate.SOURCE_LANG_AUTO, "cn");
	        logger.info(result.toString());
	        jpTxt = result.getTargetText();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		return jpTxt;
	}
}
